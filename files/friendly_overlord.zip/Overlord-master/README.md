Overlord
========

The Overlord project is a feeble attempt to re-create a simple to use vision tracking software fo robots.

The concept is pretty simple:








[![ScreenShot](https://i1.ytimg.com/vi/WyMZ6iGWpj4/mqdefault.jpg)](https://www.youtube.com/watch?v=WyMZ6iGWpj4)

Details can be found here:

http://www.instructables.com/id/How-to-Track-your-Robot-with-OpenCV/

http://letsmakerobots.com/node/38208
